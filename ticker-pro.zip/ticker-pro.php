<?php
/*
  Plugin Name:Ticker Pro
  Plugin URI: Ticker.com
  Description: Used by millions, Ticker is quite possibly the best way in the world to <strong>protect your blog from spam</strong>. It keeps your site protected even while you sleep. To get started: activate the Ticker plugin and then go to your Ticker Settings page to set up your API key.
  Version: 1.0
  Author: Automattic
  Author URI: https://automattic.com/wordpress-plugins/
  License: GPLv2 or later
  Text Domain: Ticker
 */

// Make sure we don't expose any info if called directly
if (!function_exists('add_action')) {
    echo 'Hi there!  I\'m just a plugin, not much I can do when called directly.';
    exit;
}

define('TICKER_PRO_PLUGIN_DIR', plugin_dir_path(__FILE__));



require_once( TICKER_PRO_PLUGIN_DIR . '\includes\form-handler.php' );
require_once( TICKER_PRO_PLUGIN_DIR . '\includes\plugin_init.php' );
include_once( TICKER_PRO_PLUGIN_DIR . '\includes\plugin_script.php');
require_once( TICKER_PRO_PLUGIN_DIR . '\includes\plugin_shortcode.php' );
require_once( TICKER_PRO_PLUGIN_DIR . '\includes\form-view.php' );



//Activation Hook
register_activation_hook(__FILE__, 'ticker_pro_6489_install');
//Deactivation Hook
//register_deactivation_hook(__FILE__, '');
//Uninstallhook
register_uninstall_hook(__FILE__, 'ticker_pro_6489_uninstall');



// create custom plugin settings menu
add_action('admin_menu', 'ticker_pro_menu');
function ticker_pro_menu() {
    //create new top-level menu
  add_menu_page('My Cool Plugin Settings', 'Ticker Pro', 'administrator', __FILE__, 'ticker_pro_settings_page_view', 'dashicons-hammer');
  
}




