<?php

function ticker_pro_admin_style($hook) {
    
        if($hook != 'toplevel_page_ticker-pro/ticker-pro') {
                return;
        }
        wp_enqueue_style( 'ticker_pro_admin_css',plugins_url('ticker-pro/css/main.css'));
        wp_enqueue_style( 'bootstrap_admin_css',plugins_url('ticker-pro/css/bootstrap.min.css'));
       
}
add_action( 'admin_enqueue_scripts', 'ticker_pro_admin_style' );


function ticker_plugin_script() {

    wp_enqueue_script('jquery');
    wp_enqueue_script('jquery_ticker', plugins_url('ticker-pro/js/jquery.ticker.js'), array('jquery'), 2.1, true);
}
add_action('init', 'ticker_plugin_script');

function ticker_init_script() {
    ?>
    <script type="text/javascript">
        jQuery(document).ready(function () {
            jQuery('.ticker').ticker();
            
        });

    </script>

    <?php

}
add_action('wp_head', 'ticker_init_script', 1000);



function ticker_style() {
    ?>
    <style>
        .ticker {
            width: 500px;
            margin: 10px auto;
        }
        /* The HTML list gets replaced with a single div,
           which contains the active ticker item, so you
           can easily style that as well */
        .ticker div {
            display: inline;
            word-wrap: break-word;
        }
    </style>    
    <?php

}
add_action('wp_head', 'ticker_style');