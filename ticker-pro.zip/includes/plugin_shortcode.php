<?php

function custom_shortcode() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'ticker_pro_6489';
    $sql = "SELECT name FROM $table_name ORDER BY id DESC";
    $results = $wpdb->get_results($sql);
    ?>
    <div class="ticker">
        <strong>News:</strong>
        <ul>
            <?php foreach ($results as $result) { ?>
                <li><?php echo $result->name; ?></li>
            <?php } ?>

        </ul>
    </div>
    <?php
}

add_shortcode('ticker', 'custom_shortcode');
