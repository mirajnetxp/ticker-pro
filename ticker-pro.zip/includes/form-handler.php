<?php

if ('POST' == $_SERVER['REQUEST_METHOD'] && !empty($_POST['_wpnonce']) ) {
    
    
    if (!empty($_POST['ticker_text'])) {

        global $wpdb;
        $ticker_text = $_POST['ticker_text'];
        $table_name = $wpdb->prefix . 'ticker_pro_6489';

        $wpdb->insert(
                $table_name, array(
                    'name' => $ticker_text,
                )
        );
    } elseif (!empty($_POST['edit_ticker'])) {
        
        
    }elseif (!empty($_POST['delete_ticker']) && !empty($_POST['ticker_id'])) {
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'ticker_pro_6489';
        $ticker_id=$_POST['ticker_id'];
        $wpdb->delete( $table_name, array( 'id' => $ticker_id ), array( '%d' ) );
    }
} 